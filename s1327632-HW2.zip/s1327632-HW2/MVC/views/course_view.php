<?php
require_once "courseController.php";
$controller=new courseController();
$courses=$controller->getCourses();
 ?>

<!DOCTYPE html>
<html>
<head>
<title> Course Page</title>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
  <nav>
    <a href="./index_view.php">Home</a>
    <a href="./contact_view.php">Contact</a>
  </nav>
<h2>Course Table</h2>

<table>
  <tr>
    <th>Courses</th>
    <th>professor</th>
    <th>days</th>
  </tr>
  <?php
  foreach($courses as $course){
  ?>
    <tr>
      <td><?php echo htmlspecialchars($course['course']);?></td>
      <td><?php echo htmlspecialchars($course['professor']);?></td>
      <td><?php echo htmlspecialchars($course['days']);?></td>
    </tr>
    <?php
  }
  ?>
</table>

</body>
</html>
