<!DOCTYPE html>
<html>
<head>
<title> contact page  </title>
</head>
<body>
  <nav>
    <a href="<?php echo './index_view.php';?>">Home</a>
    <a href="<?php echo './courses_view.php';?>">Courses</a>
  </nav>

<h1> My contact Information </h1>
<a href="<?php echo 'https://github.com/AmaniM22/cs357.git';?>">My github</a>
<a href="<?php echo 'https://www.youtube.com/@amanisabrina1294/featured';?>"> My youtube</a>
<a href="<?php echo 'https://www.linkedin.com/in/amani-minaya-b314ba253?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BvOBCg57DSv6n1zK2QKJfkg%3D%3D';?>">My linkedin</a>
</body>
</html>
