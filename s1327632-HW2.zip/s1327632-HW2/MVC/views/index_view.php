<?php

// Setting up the PHP variables for the controller file
$contacts_page = "./contact.html";
$courses_page = "./courses.html";
$image_src = "AmaniMPicture.jpg";
$image_alt = "My picture";
$image_width = "104";
$image_height = "142";

require_once "userController.php";
$userController= new userController();
// using UserController methods to fetch data for the view file
$contacts_page = $userController->getContactsPage();
$courses_page = $userController->getCoursesPage();
$image_src = $userController->getImageSrc();
$image_alt = $userController->getImageAlt();
$image_width = $userController->getImageWidth();
$image_height = $userController->getImageHeight();

?>
<!DOCTYPE html>
<html>
<head>
<title> Home page </title>
</head>
<body>
  <nav>
    <a href="<?php echo $contacts_page; ?>">Contacts</a>
    <a href="<?php echo $courses_page; ?>">Courses</a>
  </nav>

<h1> About me </h1>
<img src= "<?php echo $image_src; ?>" alt="<?php echo $image_alt; ?>" width="<?php echo $image_width; ?>" height="<?php echo $image_height; ?>">
<p> Hello, My name is Amani Minaya. I am currently a student at monmouth university studying to become a computer programmer!
<p> I own 3 dogs, Stella, Sterling, and their son Arlo. I hang out with them mostly on my free time but when I'm not with them I'm probably dancing. </p>
<p> My favorite color is green and my favorite sport is Basketball</P>

</body>
</html>
