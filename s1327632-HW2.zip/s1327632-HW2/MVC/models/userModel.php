//create the data structure for your user data
<?php
class userModel {
	public function getContactsPage() {
		return "./contact_view.php";
	}

	public function getCoursesPage() {
		return "./courses_view.php";
	}

	public function getImageSrc() {
		return "AmaniMPicture.jpg";
	}

	public function getImageAlt() {
		return "My picture";
	}

	public function getImageWidth() {
		return "104";
	}

	public function getImageHeight() {
		return "142";
	}
}
