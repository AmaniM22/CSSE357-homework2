//create the data structure for your course data and functions
class courseModel {
    public function getCourses() {
        $courses= [
            ['course'=> 'CO-120-02 Critical Discourse', 'professor'=>'Schmidt','days'=>'T/TH'],
            ['course'=> 'CS205L-Data Struc & Algor lab','professor'=>'kamp','days'=>'M/W'],
            ['course'=> 'CS205-Data Struc & Algor', 'professor'=>'kamp','days'=>'M/W'],
            ['course'=> 'CS357-Eng Web-Based system','professor'=>'Lakshmanan','days'=>'M/TH'],
            ['course'=> 'CO120-02-Interpersonal communications','professor'=>'Sanford','days'=>'W']
        ];
        return json_encode($courses);
    }
}
