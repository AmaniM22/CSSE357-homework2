//manage all user related interactions btw views & models
<?php
require_once 'userModel.php';

class userController {
    private $model;

    public function __construct() {
        $this->model = new userModel();
    }

    public function getContactsPage() {
        return $this->model->getContactsPage();
    }

    public function getCoursesPage() {
        return $this->model->getCoursesPage();
    }

    public function getImageSrc() {
        return $this->model->getImageSrc();
    }

    public function getImageAlt() {
        return $this->model->getImageAlt();
    }

    public function getImageWidth() {
        return $this->model->getImageWidth();
    }

    public function getImageHeight() {
        return $this->model->getImageHeight();
_HOME
}
