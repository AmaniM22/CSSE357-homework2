
require_once "courseModel.php";

class courseController {
    private $model;

    public function __construct() {
        $this->model = new courseModel();
    }

    public function getCourses() {
      $json_courses = $this->model->getCourses();
      $decoded_courses = json_decode($json_courses, true);
      return $decoded_courses; 
    }
}
