<!DOCTYPE html>
<html>
<?php
require_once '../models/contact_model.php';

$githubLink = "https://github.com/AmaniM22/cs357.git"
$youtube = "https://www.youtube.com/@amanisabrina1294/featured"
$linkedin ="https://www.linkedin.com/in/amani-minaya-b314ba253?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BvOBCg57DSv6n1zK2QKJfkg%3D%3D"

include '../views/contact_view.php'
?>
</html>
