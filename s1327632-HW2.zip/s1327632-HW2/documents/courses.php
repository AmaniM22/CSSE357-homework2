<?php require_once "courseController.php"; ?>
<?php

$courses = [
    [
        'course_name' => 'CO-120-02 Critical Discourse',
        'professor' => 'Schmidt',
        'days' => 'T/TH'
    ],
    [
        'course_name' => 'CS205L-Data Struc & Algor lab',
        'professor' => 'Kamp',
        'days' => 'M/W'
    ],
    [
        'course_name' => 'CS205-Data Struc & Algor',
        'professor' => 'Kamp',
        'days' => 'M/W'
    ],
    [
        'course_name' => 'CS357-Eng Web-Based system',
        'professor' => 'Lakshmanan',
        'days' => 'M/TH'
    ],
    [
        'course_name' => 'CO120-02-Interpersonal communications',
        'professor' =>  'Sanford',
        'days' => 'W'
    ]
];

?>

<!-- Replace the table in the HTML file -->
<table>
  <tr>
    <th>Courses</th>
    <th>professor</th>
    <th>days</th>
  </tr>
  <?php foreach($courses as $course): ?>
  <tr>
    <td><?php echo $course['course_name']; ?></td>
    <td><?php echo $course['professor']; ?></td>
    <td><?php echo $course['days']; ?></td>
  </tr>
  <?php endforeach; ?>
</table>
