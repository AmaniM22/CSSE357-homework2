<!DOCTYPE html>
<html>
<?php
<head>
<title> Home page </title>
</head>
<body>
  <nav>
    <a href="./contact.html">Contacts</a>
    <a href="./courses.html">Courses</a>
  </nav>

<h1> About me </h1>
<img src= "AmaniMPicture.jpg" alt="My picture" width="104" height="142">
<p> Hello, My name is Amani Minaya. I am currently a student at monmouth university studying to become a computer programmer!
<p> I own 3 dogs, Stella, Sterling, and their son Arlo. I hang out with them mostly on my free time but when I'm not with them I'm probably dancing. </p>
<p> My favorite color is green and my favorite sport is Basketball</P>

</body>
?>
</html>
